/* DHTML-Bibliothek */

var DHTML = 0, DOM = 0, MS = 0, NS = 0;

function DHTML_init() {
 var rVal;
 if(document.getElementById) {
   DHTML = 1;
   DOM = 1;
 }
 else if(document.all) {
   DHTML = 1;
   MS = 1;
 }
 else if(document.layers) {
   DHTML = 1;
   NS = 1;
 }
 else
   DHTML = 0;
 return(DHTML);
}

function getElem(p1,p2,p3) {
 var Elem;
 if(DOM) {
   if(p1.toLowerCase()=="id") {
     Elem = document.getElementById(p2);
     return(Elem);
   }
   else if(p1.toLowerCase()=="name") {
     Elem = document.getElementsByName(p2)[p3];
     return(Elem);
   }
   else if(p1.toLowerCase()=="tagname") {
     Elem = document.getElementsByTagName(p2)[p3];
     return(Elem);
   }
   else return(0);
 }
 else if(MS) {
   if(p1.toLowerCase()=="id") {
     Elem = eval("document.all."+p2);
     return(Elem);
   }
   else if(p1.toLowerCase()=="tagname") {
     Elem = eval("document.all.tags(\""+p2+"\")["+p3+"]");
     return(Elem);
   }
   else return(0);
 }
 else if(NS) {
   if(p1.toLowerCase()=="id") {
     Elem = eval("document."+p2);
     return(Elem);
   }
   else if(p1.toLowerCase()=="index") {
     Elem = eval("document.layers["+p2+"]");
     return(Elem);
   }
   else return(0);
 }
}

function getCont(p1,p2,p3) {
   var Cont;
   if(DOM) {
     if(getElem(p1,p2,p3).firstChild.nodeType == 3)
       Cont = getElem(p1,p2,p3).firstChild.nodeValue;
     else
       Cont = "";
     return(Cont);
   }
   else if(MS) {
     Cont = getElem(p1,p2,p3).innerText;
     return(Cont);
   }
   else return(0);
}

function getAttr(p1,p2,p3,p4) {
   var Attr;
   if(DOM || MS) {
     Attr = getElem(p1,p2,p3).getAttribute(p4);
     return(Attr);
   }
   else return(0);
}

function setCont(p1,p2,p3,p4) {
   if(DOM)
     getElem(p1,p2,p3).firstChild.nodeValue = p4;
   else if(MS)
     getElem(p1,p2,p3).innerText = p4;
   else if(NS) {
     getElem(p1,p2,p3).document.open();
     getElem(p1,p2,p3).document.write(p4);
     getElem(p1,p2,p3).document.close();
   }
}

